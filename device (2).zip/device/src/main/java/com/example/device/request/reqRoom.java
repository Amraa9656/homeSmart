package com.example.device.request;

public class reqRoom
{

}
